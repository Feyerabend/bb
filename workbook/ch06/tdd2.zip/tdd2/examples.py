"""
Practical Examples for the Virtual Machine
Demonstrates real-world programming patterns
"""

from vm import VirtualMachine, run_program


def example_calculator():
    """
    Simple calculator program.
    Calculates: (10 + 5) * 2 - 3 = 27
    """
    print("=== Calculator Example ===")
    program = [
        ("MOV", "R0", 10),
        ("ADD", "R0", 5),      # R0 = 15
        ("MUL", "R0", 2),      # R0 = 30
        ("SUB", "R0", 3),      # R0 = 27
        ("PRINT", "R0"),
        ("HALT",)
    ]
    vm = run_program(program, debug=True)
    print(f"Result: {vm.get_register('R0')}\n")


def example_array_sum():
    """
    Simulate summing an array using stack.
    Array: [5, 10, 15, 20]
    Expected sum: 50
    """
    print("=== Array Sum Example ===")
    program = [
        # Push array values onto stack
        ("PUSH", 5),
        ("PUSH", 10),
        ("PUSH", 15),
        ("PUSH", 20),
        
        # Sum loop (4 iterations)
        ("MOV", "R0", 0),          # sum = 0
        ("MOV", "R1", 4),          # count = 4
        
        ("CMP", "R1", 0),          # Loop condition
        ("JMP_IF", "ZERO", 11),
        ("POP", "R2"),             # Get next value
        ("ADD", "R0", "R2"),       # Add to sum
        ("SUB", "R1", 1),          # Decrement count
        ("JMP", 6),
        
        ("PRINT", "R0"),           # Print sum
        ("HALT",)
    ]
    vm = run_program(program)
    print(f"Sum: {vm.get_register('R0')}\n")


def example_min_max():
    """
    Find minimum and maximum of three numbers.
    Numbers: 15, 7, 23
    Min: 7, Max: 23
    """
    print("=== Min/Max Example ===")
    program = [
        # Initialize with three numbers
        ("MOV", "R0", 15),
        ("MOV", "R1", 7),
        ("MOV", "R2", 23),
        
        # Find minimum (start with R0)
        ("MOV", "R3", "R0"),       # min = R0
        ("CMP", "R1", "R3"),
        ("JMP_IF", "GREATER", 8),  # R1 > min?
        ("MOV", "R3", "R1"),       # min = R1
        
        ("CMP", "R2", "R3"),
        ("JMP_IF", "GREATER", 11), # R2 > min?
        ("MOV", "R3", "R2"),       # min = R2
        
        # Find maximum (start with R0)
        ("MOV", "R4", "R0"),       # max = R0
        ("CMP", "R1", "R4"),
        ("JMP_IF", "LESS", 15),    # R1 < max?
        ("MOV", "R4", "R1"),       # max = R1
        
        ("CMP", "R2", "R4"),
        ("JMP_IF", "LESS", 18),    # R2 < max?
        ("MOV", "R4", "R2"),       # max = R2
        
        ("PRINT", "R3"),           # Print min
        ("PRINT", "R4"),           # Print max
        ("HALT",)
    ]
    vm = run_program(program)
    print(f"Min: {vm.get_register('R3')}")
    print(f"Max: {vm.get_register('R4')}\n")


def example_is_prime():
    """
    Check if a number is prime.
    Number: 17 (is prime)
    """
    print("=== Prime Check Example ===")
    program = [
        ("MOV", "R0", 17),         # Number to check
        ("MOV", "R1", 2),          # Divisor
        ("MOV", "R2", 1),          # is_prime flag (1 = true)
        
        # Loop: check divisors from 2 to n-1
        ("CMP", "R1", "R0"),
        ("JMP_IF", "ZERO", 15),    # If divisor == n, done
        
        # Check if n % divisor == 0
        ("MOV", "R3", "R0"),       # temp = n
        ("MOD", "R3", "R1"),       # temp = n % divisor
        ("CMP", "R3", 0),
        ("JMP_IF", "ZERO", 13),    # Found divisor, not prime
        
        # Continue loop
        ("ADD", "R1", 1),          # divisor++
        ("JMP", 3),
        
        # Not prime
        ("MOV", "R2", 0),          # is_prime = false
        
        ("PRINT", "R2"),           # Print result
        ("HALT",)
    ]
    vm = run_program(program)
    result = vm.get_register("R2")
    print(f"17 is {'prime' if result == 1 else 'not prime'}\n")


def example_string_length_simulation():
    """
    Simulate counting string length using ASCII values.
    String represented as: [72, 101, 108, 108, 111, 0]  # "Hello\0"
    """
    print("=== String Length Simulation ===")
    program = [
        # Push string onto stack (null-terminated)
        ("PUSH", 0),               # Null terminator
        ("PUSH", 111),             # 'o'
        ("PUSH", 108),             # 'l'
        ("PUSH", 108),             # 'l'
        ("PUSH", 101),             # 'e'
        ("PUSH", 72),              # 'H'
        
        # Count characters
        ("MOV", "R0", 0),          # length = 0
        
        ("POP", "R1"),             # Get character
        ("CMP", "R1", 0),          # Check if null
        ("JMP_IF", "ZERO", 12),    # End if null
        ("ADD", "R0", 1),          # length++
        ("JMP", 7),                # Continue
        
        ("PRINT", "R0"),           # Print length
        ("HALT",)
    ]
    vm = run_program(program)
    print(f"Length: {vm.get_register('R0')}\n")


def example_bubble_sort():
    """
    Bubble sort simulation using registers.
    Sort: [5, 2, 8, 1] -> [1, 2, 5, 8]
    """
    print("=== Bubble Sort Example ===")
    # This is simplified - in practice would need memory
    # Here we just demonstrate one pass of comparisons
    program = [
        # Load array into registers
        ("MOV", "R0", 5),
        ("MOV", "R1", 2),
        ("MOV", "R2", 8),
        ("MOV", "R3", 1),
        
        # Compare and swap R0, R1
        ("CMP", "R0", "R1"),
        ("JMP_IF", "LESS", 10),    # Already in order
        # Swap
        ("MOV", "R4", "R0"),       # temp = R0
        ("MOV", "R0", "R1"),       # R0 = R1
        ("MOV", "R1", "R4"),       # R1 = temp
        
        # Compare and swap R1, R2
        ("CMP", "R1", "R2"),
        ("JMP_IF", "LESS", 15),
        ("MOV", "R4", "R1"),
        ("MOV", "R1", "R2"),
        ("MOV", "R2", "R4"),
        
        # Compare and swap R2, R3
        ("CMP", "R2", "R3"),
        ("JMP_IF", "LESS", 20),
        ("MOV", "R4", "R2"),
        ("MOV", "R2", "R3"),
        ("MOV", "R3", "R4"),
        
        # Print sorted values
        ("PRINT", "R0"),
        ("PRINT", "R1"),
        ("PRINT", "R2"),
        ("PRINT", "R3"),
        ("HALT",)
    ]
    vm = run_program(program)
    print(f"After one pass: {[vm.get_register(f'R{i}') for i in range(4)]}\n")


def example_recursive_countdown():
    """
    Recursive countdown using CALL/RET.
    Countdown from 5 to 1.
    """
    print("=== Recursive Countdown ===")
    program = [
        # Main
        ("MOV", "R0", 5),          # Start value
        ("CALL", 3),               # Call countdown
        ("HALT",),
        
        # countdown function
        ("PRINT", "R0"),           # Print current value
        ("CMP", "R0", 1),
        ("JMP_IF", "ZERO", 9),     # Base case
        ("SUB", "R0", 1),          # Decrement
        ("CALL", 3),               # Recursive call
        ("RET",)
    ]
    vm = run_program(program)
    print()


def example_binary_counter():
    """
    Count in binary using bitwise operations.
    Count from 0 to 7 showing binary representation.
    """
    print("=== Binary Counter ===")
    program = [
        ("MOV", "R0", 0),          # Counter
        ("MOV", "R1", 8),          # Limit
        
        # Loop
        ("CMP", "R0", "R1"),
        ("JMP_IF", "ZERO", 7),
        
        ("PRINT", "R0"),           # Print counter
        ("ADD", "R0", 1),          # Increment
        ("JMP", 2),
        
        ("HALT",)
    ]
    vm = run_program(program)
    print()


def example_conditional_absolute_value():
    """
    Calculate absolute value.
    Test with -15, should return 15.
    """
    print("=== Absolute Value ===")
    program = [
        ("MOV", "R0", -15),        # Input
        ("CMP", "R0", 0),
        ("JMP_IF", "GREATER", 5),  # Already positive
        ("JMP_IF", "ZERO", 5),     # Already zero
        # Negative case
        ("MOV", "R1", 0),
        ("SUB", "R1", "R0"),       # R1 = 0 - R0
        ("MOV", "R0", "R1"),       # R0 = |R0|
        
        ("PRINT", "R0"),
        ("HALT",)
    ]
    vm = run_program(program)
    print(f"Absolute value: {vm.get_register('R0')}\n")


def example_power_of_two():
    """
    Check if a number is a power of two.
    Use bitwise AND trick: n & (n-1) == 0
    Test: 16 (is power of 2)
    """
    print("=== Power of Two Check ===")
    program = [
        ("MOV", "R0", 16),         # Number to check
        ("MOV", "R1", "R0"),       # Copy
        ("SUB", "R1", 1),          # n - 1
        ("AND", "R0", "R1"),       # n & (n-1)
        ("CMP", "R0", 0),
        ("JMP_IF", "ZERO", 8),     # Is power of 2
        
        ("MOV", "R2", 0),          # Not power of 2
        ("JMP", 9),
        ("MOV", "R2", 1),          # Is power of 2
        
        ("PRINT", "R2"),
        ("HALT",)
    ]
    vm = run_program(program)
    result = vm.get_register("R2")
    print(f"16 is {'a' if result == 1 else 'not a'} power of 2\n")


def example_collatz_sequence():
    """
    Generate Collatz sequence (3n+1 problem).
    Starting with 10: 10, 5, 16, 8, 4, 2, 1
    """
    print("=== Collatz Sequence ===")
    program = [
        ("MOV", "R0", 10),         # Starting number
        
        # Loop
        ("PRINT", "R0"),           # Print current number
        ("CMP", "R0", 1),
        ("JMP_IF", "ZERO", 17),    # Done when reach 1
        
        # Check if even or odd
        ("MOV", "R1", "R0"),
        ("MOD", "R1", 2),          # R1 = R0 % 2
        ("CMP", "R1", 0),
        ("JMP_IF", "ZERO", 13),    # Even case
        
        # Odd case: 3n + 1
        ("MUL", "R0", 3),
        ("ADD", "R0", 1),
        ("JMP", 2),
        
        # Even case: n / 2
        ("DIV", "R0", 2),
        ("JMP", 2),
        
        ("HALT",)
    ]
    vm = run_program(program)
    print()


def run_all_examples():
    """Run all example programs."""
    examples = [
        example_calculator,
        example_array_sum,
        example_min_max,
        example_is_prime,
        example_string_length_simulation,
        example_bubble_sort,
        example_recursive_countdown,
        example_binary_counter,
        example_conditional_absolute_value,
        example_power_of_two,
        example_collatz_sequence,
    ]
    
    for example in examples:
        try:
            example()
        except Exception as e:
            print(f"Error in {example.__name__}: {e}\n")


if __name__ == "__main__":
    run_all_examples()
