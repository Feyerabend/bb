# Virtual Machine - No External Dependencies

A complete register-based virtual machine implementation with comprehensive tests, all using only Python's standard library.

## Files

- **vm.py** - The virtual machine implementation
- **test_vm.py** - Comprehensive test suite (no pytest required!)
- **examples.py** - Practical examples demonstrating real-world programming patterns

## Quick Start

### Running Tests

Simply run the test file directly with Python:

```bash
python test_vm.py
```

The test runner will execute all tests and display results with a summary. You'll see:
- ✓ for passing tests
- ✗ for failing tests
- A summary at the end showing total, passed, and failed counts

### Running Examples

Execute the examples file to see the VM in action:

```bash
python examples.py
```

This will run all example programs showing various algorithms and patterns.

### Using the VM

```python
from vm import VirtualMachine, run_program

# Create a simple program
program = [
    ("MOV", "R0", 10),
    ("ADD", "R0", 5),
    ("PRINT", "R0"),
    ("HALT",)
]

# Run it
vm = run_program(program, debug=True)
print(f"Result: {vm.get_register('R0')}")
```

## Features

### Instructions Supported

**Data Movement:**
- MOV - Move value to register
- PUSH - Push to stack
- POP - Pop from stack

**Arithmetic:**
- ADD, SUB, MUL, DIV, MOD

**Bitwise Logic:**
- AND, OR, XOR, NOT

**Control Flow:**
- CMP - Compare values
- JMP - Unconditional jump
- JMP_IF - Conditional jump (ZERO, LESS, GREATER)
- CALL - Function call
- RET - Return from function
- HALT - Stop execution

**Debugging:**
- PRINT - Print register value

### Registers

10 general-purpose registers: R0 through R9

### Error Handling

The VM includes comprehensive error handling:
- StackUnderflowError
- InvalidRegisterError
- DivisionByZeroError
- InvalidJumpError
- ReturnWithoutCallError

## Test Organization

Tests are organized into logical groups:

- **TestDataMovement** - MOV, PUSH, POP
- **TestArithmetic** - ADD, SUB, MUL, DIV, MOD
- **TestBitwiseLogic** - AND, OR, XOR, NOT
- **TestComparisonAndControlFlow** - CMP, JMP, CALL, RET
- **TestCompletePrograms** - Full algorithms (factorial, fibonacci, GCD, etc.)
- **TestEdgeCases** - Edge cases and error conditions
- **TestDebugging** - Debug features
- **TestPerformance** - Performance with large programs


## Example Programs Included

The examples.py file demonstrates:
- Calculator operations
- Array sum
- Min/Max finding
- Prime checking
- String length simulation
- Bubble sort
- Recursive countdown
- Binary counter
- Absolute value
- Power of two check
- Collatz sequence

## Writing Your Own Tests

The test file uses a simple custom test runner. To add your own tests:

```python
class TestMyFeature:
    """Test my new feature."""
    
    def test_something(self):
        """Test description."""
        vm = get_fresh_vm()
        vm.execute([
            ("MOV", "R0", 42)
        ])
        assert vm.get_register("R0") == 42
    
    def test_error_handling(self):
        """Test that errors are raised."""
        vm = get_fresh_vm()
        assert_raises(InvalidRegisterError,
                     lambda: vm.execute([("MOV", "R99", 1)]))
```

Then add your test class to the `test_classes` list in the `main()` function.

## Development Workflow

1. Write tests first (TDD approach)
2. Run tests: `python test_vm.py`
3. Implement features
4. Run tests again to verify
5. Add examples to demonstrate usage

## License

Feel free to use this code for learning, teaching, or any other purpose!
