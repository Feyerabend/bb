
public class Sample extends java.lang.Object {
    Sample() {
        super();
    }
    public static void main(java.lang.String[] args) {
        java.lang.System.out.println("Hi!");
    }
}
