
class Sample2 {
    int x = 42;
    public static void main(String[] args) {
        Sample2 example = new Sample2();
        System.out.println(example.x);
    }
}

