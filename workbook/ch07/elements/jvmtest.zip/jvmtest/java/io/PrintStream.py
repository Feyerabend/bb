class PrintStream:
    def println(self, value):
        print(value)