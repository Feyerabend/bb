from java.io.PrintStream import PrintStream

out = PrintStream()